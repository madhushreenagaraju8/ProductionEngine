﻿using System;
using System.Collections.Generic;

namespace PromotionEngine.Business
{
    public interface IProcessEngine:IDisposable
    {
        void CalculateUnitsAgainstPromotions(List<string> lstProducts);
        void DisplayUnitsPromotions();
        Dictionary<char,int> AddPromotionUnits(IEnumerable<string> eachPromotionUnits);
        void AddPromotion(Dictionary<char, int> objResult, int intValue);
        void UpdateUnitPrice(char cUnit, int intPrice);
    }
}
