﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using PromotionEngine.Model;

namespace PromotionEngine.Business
{
    public class ProcessEngine:DisposeMemory,IProcessEngine
    {
        #region Process Engine execute Scenarios

        #region Global variables
        ProcessEngineModel ObjProcessEngineModel = new ProcessEngineModel();
        //To store unit value
        readonly List<SKUId> lstsKUIds;      

        int intTotal = 0;

        #endregion

        /// <summary>
        /// Constructor to initialize engine models
        /// </summary>
        public ProcessEngine()
        {
            //Initialize engine objects
            ObjProcessEngineModel.ObjSkuid = new SKUId { DictSkuId = new Dictionary<char, int>() };
            ObjProcessEngineModel.LstSkuPromotions = new List<SKUPromotions>();
            lstsKUIds = new List<SKUId>();
            ObjProcessEngineModel.LstScenariosValues = new List<string>();
        }

        #region Interface implementations

        /// <summary>
        /// Module to update unit and price
        /// </summary>
        /// <param name="cUnit"></param>
        /// <param name="intPrice"></param>
        public void UpdateUnitPrice(char cUnit,int intPrice)
        {
            ObjProcessEngineModel.ObjSkuid.DictSkuId.Add(cUnit, intPrice);
        }

        /// <summary>
        /// Function to add the promotions
        /// </summary>
        /// <param name="objResult"></param>
        /// <param name="intValue"></param>
        public void AddPromotion(Dictionary<char, int> objResult, int intValue)
        {
            SKUPromotions objSkuPromotions = new SKUPromotions { DictSkuId = objResult , IntPromotionValue = intValue };
            ObjProcessEngineModel.LstSkuPromotions.Add(objSkuPromotions);
        }
       
        /// <summary>
        /// Update promotions units for multiple units
        /// </summary>
        /// <param name="eachPromotionUnits"></param>
        /// <returns></returns>
        public Dictionary<char, int> AddPromotionUnits(IEnumerable<string> eachPromotionUnits)
        {
            SKUId objeachPromotions = new SKUId { DictSkuId = new Dictionary<char, int>() };
            foreach (var eachUnit in eachPromotionUnits)
            {
                Console.Write("Enter number of units for {0} : ", eachUnit);
                int intNumOfUnits = Convert.ToInt32(Console.ReadLine());
                objeachPromotions.DictSkuId.Add(Convert.ToChar(eachUnit), intNumOfUnits);
            }
            return objeachPromotions.DictSkuId;
        }


        /// <summary>
        /// Display the units and respective promotions
        /// </summary>
        public void DisplayUnitsPromotions()
        {
            Console.WriteLine("\n\n----------------------");
            Console.WriteLine("Entered Units and their respective price\n");
            foreach (var eachUnit in ObjProcessEngineModel.ObjSkuid.DictSkuId)
            {
                Console.WriteLine(eachUnit.Key + " - " + eachUnit.Value);
            }
            Console.WriteLine("----------------------\n");
            Console.WriteLine("Entered Promotions respective price\n");
            foreach (var eachPromotion in ObjProcessEngineModel.LstSkuPromotions)
            {
                foreach (var eachUnit in eachPromotion.DictSkuId)
                {
                    Console.WriteLine("For "+eachUnit.Value +" Units of "+ eachUnit.Key );
                }
                Console.WriteLine("Promotion Value : "+eachPromotion.IntPromotionValue + "\n");
            }

        }

        /// <summary>
        /// Calculate the products against Promotions
        /// </summary>
        /// <param name="lstProducts"></param>
        public void CalculateUnitsAgainstPromotions(List<string> lstProducts)
        {
            SKUId objScenarios = new SKUId { DictSkuId = new Dictionary<char, int>() };
            foreach (string streachUnit in lstProducts)
            {
                
                try
                {
                    objScenarios.DictSkuId.Add(Convert.ToChar(streachUnit.Split('*')[1]), Convert.ToInt32(streachUnit.Split('*')[0]));

                }
                catch(Exception ex)
                {
                    Console.WriteLine("Error : " + ex.Message);
                }
                
            }
            CheckPromotion(objScenarios.DictSkuId);
        }

        #endregion

        #region Private functions
        /// <summary>
        /// Module to check whether promotion can be applied to products
        /// </summary>
        /// <param name="dictScenarios"></param>
        private void CheckPromotion(Dictionary<char, int> dictScenarios)
        {
            NameValueCollection nvcPromotion = new NameValueCollection();
            
            Dictionary<char, int> cloneScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
            intTotal = 0;
            bool blnPromotionApplied = true;
            ObjProcessEngineModel.LstScenariosValues.Add("\n----Calculate Scenarios-----\n\n");
            while (blnPromotionApplied)
            {
                blnPromotionApplied = ProcessScenariosForPromotion(dictScenarios, cloneScenarios);
            }
            CalculateNonPromotionUnits(cloneScenarios);
            foreach (var eachPrdDetails in ObjProcessEngineModel.LstScenariosValues)
                Console.Write(eachPrdDetails);
            Console.WriteLine("======\nTotal     "+intTotal);
        }

        /// <summary>
        /// Calculate the price for the units where promotions are not applied 
        /// </summary>
        /// <param name="cloneScenarios"></param>
        private void CalculateNonPromotionUnits(Dictionary<char, int> cloneScenarios)
        {
            var GetUnits = cloneScenarios.Where(x => x.Value > 0).ToList();
            ObjProcessEngineModel.LstScenariosValues.Add("----Without Promotions-----\n");
            foreach(var individualValue in cloneScenarios.Where(x => x.Value > 0).ToList())
            {
                var result=Convert.ToInt32(ObjProcessEngineModel.ObjSkuid.DictSkuId.Where(x => x.Key == individualValue.Key).Select(y => y.Value).FirstOrDefault())* 
                    individualValue.Value;
                ObjProcessEngineModel.LstScenariosValues.Add(individualValue.Value + "*" + individualValue.Key +" is "+ result+" \n");
                intTotal += result;
            }
        }

        /// <summary>
        /// Calculate the price of units after applying promotions
        /// </summary>
        /// <param name="dictScenarios"></param>
        /// <param name="cloneScenarios"></param>
        /// <returns></returns>
        private bool ProcessScenariosForPromotion(Dictionary<char, int> dictScenarios, Dictionary<char, int> cloneScenarios)
        {
            int intValidPromotion = -1;
            Dictionary<char, int> duplicateScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
            bool blnPromotionApplied = false;
            foreach (var eachProduct in dictScenarios)
            {
                intValidPromotion = -1;
                
                duplicateScenarios.Remove(eachProduct.Key);

                List<SKUPromotions> promotion = ObjProcessEngineModel.LstSkuPromotions.Where(x => x.DictSkuId.ContainsKey(Convert.ToChar(eachProduct.Key))
                && (x.DictSkuId[eachProduct.Key] <= cloneScenarios[eachProduct.Key])).ToList();

                foreach (var eachPromotion in promotion)
                {

                    if (eachPromotion.DictSkuId.Count > 1)
                    {
                        var applyPromotions = eachPromotion.DictSkuId.Where(x => duplicateScenarios.ContainsKey(x.Key) && x.Value <= cloneScenarios[x.Key]).FirstOrDefault();
                        if (applyPromotions.Key != 0)
                        {
                            intValidPromotion = eachPromotion.IntPromotionValue;
                            foreach (var updateUnits in eachPromotion.DictSkuId)
                            {
                                cloneScenarios[updateUnits.Key] = cloneScenarios[updateUnits.Key] - updateUnits.Value;
                                ObjProcessEngineModel.LstScenariosValues.Add("Promotion Applied " + updateUnits.Value + "*" + updateUnits.Key + " \n");
                            }
                            duplicateScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
                            break;
                        }

                    }
                    else
                    {
                        foreach (var updateUnits in eachPromotion.DictSkuId)
                        {
                            cloneScenarios[updateUnits.Key] = cloneScenarios[updateUnits.Key] - updateUnits.Value;
                            ObjProcessEngineModel.LstScenariosValues.Add("Promotion Applied " + updateUnits.Value + "*" + updateUnits.Key + " \n");
                        }
                        intValidPromotion = (intValidPromotion != -1) && intValidPromotion < eachPromotion.IntPromotionValue ?
                    intValidPromotion : eachPromotion.IntPromotionValue;
                    }

                }
                duplicateScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
                if (intValidPromotion != -1)
                {
                    ObjProcessEngineModel.LstScenariosValues.Add("Promotion Value " + intValidPromotion + " \n\n");
                    intTotal += intValidPromotion;
                    blnPromotionApplied = true;
                }
            }

            return blnPromotionApplied;
        }

        #endregion

        #endregion

    }
}
