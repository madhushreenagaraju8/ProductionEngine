﻿using System;

namespace PromotionEngine.Business
{
    public class DisposeMemory:IDisposable
    {
        private bool _isDispose = false;
        protected virtual void Dispose(bool disposing)
        {
            if (_isDispose) return;

            if (disposing) { }

            _isDispose = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
