﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace PromotionEngine.Business.ProcessEngineTestsCases
{  
    [TestClass()]
    public class ProcessEngineTestsCases
    {
        ProcessEngine objPE = new ProcessEngine();
        public ProcessEngineTestsCases()
        {
            this.DictObj = new Dictionary<char,int>();
        }

        public Dictionary<char,int> DictObj { get; private set; }

        [TestMethod()]
        public void UpdateUnitPriceTest()
        {
            try
            {
                objPE.UpdateUnitPrice('a',2);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

       

        [TestMethod()]
        public void AddPromotionTest()
        {
            try
            {
                ProcessEngineTestsCases PEtest = new ProcessEngineTestsCases
                {
                    DictObj = { { 'B', 4 } }
                };
                objPE.AddPromotion(DictObj, 2);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void AddPromotionTest1()
        {
            try
            {
                ProcessEngineTestsCases PEtest = new ProcessEngineTestsCases
                {
                    DictObj = { { 'A', 5 },{ 'B', 4 } }
                };
                objPE.AddPromotion(DictObj, 5);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void AddPromotionUnitsTest()
        {
            Dictionary<char, int> objResult1 = new Dictionary<char, int>();           
            var objResult= objPE.AddPromotionUnits(new string[] { });
            Assert.AreEqual(objResult1.Count, objResult.Count);           
            
        }

        [TestMethod()]
        public void DisplayUnitsPromotionsTest()
        {
            try
            {
                objPE.DisplayUnitsPromotions();
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CalculateUnitsAgainstPromotionsTest()
        {
            try
            {
                List<string> lstValaue = new List<string>() { "A", "B","C" };
                objPE.CalculateUnitsAgainstPromotions(lstValaue);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CheckPromotionTest()
        {
            try
            {
                PrivateObject objPO = new PrivateObject(objPE);
                Dictionary<char,int> parameters =new Dictionary<char, int>();
                objPO.Invoke("CheckPromotion",parameters);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CheckPromotionTest1()
        {
            try
            {
                PrivateObject objPO = new PrivateObject(objPE);
                ProcessEngineTestsCases PEtest = new ProcessEngineTestsCases
                {
                    DictObj = { { 'A', 1 } }
                };
                objPO.Invoke("CheckPromotion", DictObj);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CheckPromotionTest2()
        {
            try
            {
                PrivateObject objPO = new PrivateObject(objPE);
                ProcessEngineTestsCases PEtest = new ProcessEngineTestsCases
                {
                    DictObj = { { 'A', 1 },{ 'B', 2 },{ 'C', 3 },{ 'D', 4 } }
                };
               
                objPO.Invoke("CheckPromotion", DictObj);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CalculateNonPromotionUnitsTest()
        {
            try
            {
                PrivateObject objPO = new PrivateObject(objPE);
                Dictionary<char, int> parameters = new Dictionary<char, int>();
                objPO.Invoke("CalculateNonPromotionUnits", parameters);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void CalculateNonPromotionUnitsTest1()
        {
            try
            {
                PrivateObject objPO = new PrivateObject(objPE);
                ProcessEngineTestsCases PEtest = new ProcessEngineTestsCases
                {
                    DictObj = { { 'A', 1 } }
                };
                objPO.Invoke("CalculateNonPromotionUnits", DictObj);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }
        [TestMethod()]
        public void CalculateNonPromotionUnitsTest2()
        {
            try
            {
                PrivateObject objPO = new PrivateObject(objPE);
                ProcessEngineTestsCases PEtest = new ProcessEngineTestsCases
                {
                    DictObj = { { 'A', 1 },{ 'B', 2 },{ 'C', 3 },{ 'D', 4 } }
                };
                objPO.Invoke("CalculateNonPromotionUnits", DictObj);
                return;
            }
            catch (Exception ex)
            {
                Assert.Fail(ex.Message);
            }
        }

        [TestMethod()]
        public void ProcessScenariosForPromotionTest()
        { 
            PrivateObject objPO = new PrivateObject(objPE);
            Dictionary<char, int> parameters1 = new Dictionary<char, int>();
            Dictionary<char, int> parameters2 = new Dictionary<char, int>();
            object[] parameters = { parameters1, parameters2 };
            var actual=objPO.Invoke("ProcessScenariosForPromotion", parameters);
            Assert.AreEqual(false, actual);
           
        }
        [TestMethod()]
        public void ProcessScenariosForPromotionTest1()
        {
            PrivateObject objPO = new PrivateObject(objPE);
            Dictionary<char, int> parameters1 = new Dictionary<char, int>();
            Dictionary<char, int> parameters2 = new Dictionary<char, int>();
            parameters1.Add('A',1);
            parameters1.Add('B',2);
            parameters2.Add('A',0);
            
            object[] parameters = { parameters1, parameters2 };
            var actual = objPO.Invoke("ProcessScenariosForPromotion", parameters);
            Assert.AreEqual(false, actual);

        }
        [TestMethod()]
        public void ProcessScenariosForPromotionTest2()
        {
            PrivateObject objPO = new PrivateObject(objPE);
            Dictionary<char, int> parameters1 = new Dictionary<char, int>();
            Dictionary<char, int> parameters2 = new Dictionary<char, int>();
            parameters1.Add('A', 1);
            parameters1.Add('B', 2);
            parameters1.Add('C', 3);
            parameters1.Add('D', 4);
            parameters2.Add('B', 2);
            parameters2.Add('D', 1);
            object[] parameters = { parameters1, parameters2 };
            var actual = objPO.Invoke("ProcessScenariosForPromotion", parameters);
            Assert.AreEqual(false, actual);

        }
    }
}