﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PromotionEngine.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine.Business.ProcessEngineTestsCases
{
    [TestClass()]
    public class ProcessEngineProcessEngineTestsCases
    {
        [TestMethod()]
        public void AddPromotionTest()
        {
            Assert.Fail();
        }
    }
}