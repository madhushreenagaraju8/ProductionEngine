﻿using System;

//----------------------------
//Main funtion to run for Process engine
//----------------------------
namespace PromotionEngine.Process
{
    public class ProcessEngineMain
    {
       
        public static void Main()
        {
            try
            {
                new PEScenarios();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: "+ex.Message);
            }
            
        }

        
    }
}
