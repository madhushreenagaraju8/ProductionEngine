﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PromotionEngine.Model;

namespace PromotionEngine.Process
{
    public class ProcessEngine
    {
        SKUId objSkuId = new SKUId { dictSkuId = new Dictionary<char, int>() };
        

        List<SKUPromotions> lstSkuPromotions = new List<SKUPromotions>();       

        List<SKUId> lstsKUIds = new List<SKUId>();

        List<string> lstScenariosValues = new List<string>();

        int intTotal = 0;
        
        public void updateUnitPrice(char cUnit,int intPrice)
        {
            objSkuId.dictSkuId.Add(cUnit, intPrice);
        }

        //private SKUId CreatePromotionUnits(char cPromotionUnit,int intNoOfUnits)
        //{
        //    SKUId objeachPromotions = new SKUId { dictSkuId = new Dictionary<char, int>() };
        //    objeachPromotions.dictSkuId.Add(cPromotionUnit, intNoOfUnits);
        //    return objeachPromotions;
        //}

        //internal Dictionary<char,int> AddPromotionUnits(char cUnit,int intNoOfUnits)
        //{
            
        //    objeachPromotions.dictSkuId.Add(cUnit, intNoOfUnits);
        //    lstsKUIds.Add(objeachPromotions);
        //    return objeachPromotions.dictSkuId;
 
        //}

        internal List<SKUPromotions> AddPromotion(Dictionary<char, int> objResult, int intValue)
        {
            SKUPromotions objSkuPromotions = new SKUPromotions { dictSkuId=objResult ,intPromotionValue= intValue };
            lstSkuPromotions.Add(objSkuPromotions);

            return lstSkuPromotions;
        }

       

        internal Dictionary<char, int> AddPromotionUnits(IEnumerable<string> eachPromotionUnits)
        {
            SKUId objeachPromotions = new SKUId { dictSkuId = new Dictionary<char, int>() };
            // objeachPromotions.dictSkuId = new Dictionary<char, int>();
            foreach (var eachUnit in eachPromotionUnits)
            {
                Console.Write("Enter number of units for {0} : ", eachUnit);
                int intNumOfUnits = Convert.ToInt32(Console.ReadLine());
                objeachPromotions.dictSkuId.Add(Convert.ToChar(eachUnit), intNumOfUnits);
            }
            return objeachPromotions.dictSkuId;
        }

        internal void DisplayUnitsPromotions()
        {
            Console.WriteLine("\n\n----------------------");
            Console.WriteLine("Entered Units and their respective price\n");
            foreach (var eachUnit in objSkuId.dictSkuId)
            {
                Console.WriteLine(eachUnit.Key + " - " + eachUnit.Value);
            }
            Console.WriteLine("----------------------\n");
            Console.WriteLine("Entered Promotions respective price\n");
            foreach (var eachPromotion in lstSkuPromotions)
            {
                foreach (var eachUnit in eachPromotion.dictSkuId)
                {
                    Console.WriteLine("For "+eachUnit.Value +" Units of "+ eachUnit.Key );
                }
                Console.WriteLine("Promotion Value : "+eachPromotion.intPromotionValue+"\n");
            }

        }

        internal void CalculateUnitsAgainstPromotions(List<string> lstProducts)
        {
            int intNoOfUnits;
            SKUId objScenarios = new SKUId { dictSkuId = new Dictionary<char, int>() };
            foreach (string streachUnit in lstProducts)
            {
                
                try
                {
                    objScenarios.dictSkuId.Add(Convert.ToChar(streachUnit.Split('*')[1]), Convert.ToInt32(streachUnit.Split('*')[0]));

                }
                catch(Exception ex)
                {
                    Console.WriteLine("Error : " + ex.Message);
                }
                
            }
            CheckPromotion(objScenarios.dictSkuId);
        }

        private void CheckPromotion(Dictionary<char, int> dictScenarios)
        {
            NameValueCollection nvcPromotion = new NameValueCollection();
            
            Dictionary<char, int> cloneScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
            intTotal = 0;
            bool blnPromotionApplied = true;
            lstScenariosValues.Add("----Calculate Scenarios-----\n");
            while (blnPromotionApplied)
            {
                blnPromotionApplied = ProcessScenariosForPromotion(dictScenarios, cloneScenarios);
            }
            CalculateNonPromotionUnits(cloneScenarios);
            foreach (var eachPrdDetails in lstScenariosValues)
                Console.Write(eachPrdDetails);
            Console.WriteLine("======\nTotal     "+intTotal);
            Console.ReadLine();
        }

        private void CalculateNonPromotionUnits(Dictionary<char, int> cloneScenarios)
        {
            var GetUnits = cloneScenarios.Where(x => x.Value > 0).ToList();
            lstScenariosValues.Add("----Without Promotions-----\n");
            foreach(var individualValue in cloneScenarios.Where(x => x.Value > 0).ToList())
            {
                var result=Convert.ToInt32(objSkuId.dictSkuId.Where(x => x.Key == individualValue.Key).Select(y => y.Value).FirstOrDefault())* 
                    individualValue.Value;
                lstScenariosValues.Add(individualValue.Value + "*" + individualValue.Key +" is "+ result+" \n");
                intTotal += result;
            }
        }

        private bool ProcessScenariosForPromotion(Dictionary<char, int> dictScenarios, Dictionary<char, int> cloneScenarios)
        {
            int intValidPromotion = -1;
            Dictionary<char, int> duplicateScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
            bool blnPromotionApplied = false;
            foreach (var eachProduct in dictScenarios)
            {
                intValidPromotion = -1;
                //KeyValuePair<char,int> eachProduct =cloneScenarios.Where(x => x.Key == eachProductKey).Select(y=> new KeyValuePair<char, int>(y.Key, y.Value) );
                duplicateScenarios.Remove(eachProduct.Key);

                List<SKUPromotions> promotion = lstSkuPromotions.Where(x => x.dictSkuId.ContainsKey(Convert.ToChar(eachProduct.Key))
                && (x.dictSkuId[eachProduct.Key] <= cloneScenarios[eachProduct.Key])).ToList();

                foreach (var eachPromotion in promotion)
                {

                    if (eachPromotion.dictSkuId.Count > 1)
                    {
                        var applyPromotions = eachPromotion.dictSkuId.Where(x => duplicateScenarios.ContainsKey(x.Key) && x.Value <= cloneScenarios[x.Key]).FirstOrDefault();
                        if (applyPromotions.Key != 0)
                        {
                            intValidPromotion = eachPromotion.intPromotionValue;
                            foreach (var updateUnits in eachPromotion.dictSkuId)
                            {
                                cloneScenarios[updateUnits.Key] = cloneScenarios[updateUnits.Key] - updateUnits.Value;
                                lstScenariosValues.Add("Promotion Applied " + updateUnits.Value + "*" + updateUnits.Key + " \n");
                            }
                            duplicateScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
                            break;
                        }

                    }
                    else
                    {
                        foreach (var updateUnits in eachPromotion.dictSkuId)
                        {
                            cloneScenarios[updateUnits.Key] = cloneScenarios[updateUnits.Key] - updateUnits.Value;
                            lstScenariosValues.Add("Promotion Applied " + updateUnits.Value + "*" + updateUnits.Key + " \n");
                        }
                        intValidPromotion = (intValidPromotion != -1) && intValidPromotion < eachPromotion.intPromotionValue ?
                    intValidPromotion : eachPromotion.intPromotionValue;
                    }

                }
                duplicateScenarios = dictScenarios.ToDictionary(
            x => x.Key, x => x.Value);
                if (intValidPromotion != -1)
                {
                    lstScenariosValues.Add("Promotion Value " + intValidPromotion + " \n");
                    intTotal += intValidPromotion;
                    blnPromotionApplied = true;
                }
            }

            return blnPromotionApplied;
        }
    }
}
