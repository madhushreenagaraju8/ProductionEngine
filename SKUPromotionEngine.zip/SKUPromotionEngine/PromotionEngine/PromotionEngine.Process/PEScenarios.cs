﻿using System;
using System.Collections.Generic;
using System.Linq;
using PromotionEngine.Business;

namespace PromotionEngine.Process
{
    public class PEScenarios :DisposeMemory
    {
        private readonly IProcessEngine objProcessEngine=new ProcessEngine();

        #region Select Options to perform operations

        /// <summary>
        /// Constructor to call options to select
        /// </summary>
        public PEScenarios()
        {
            Console.Write("Enter number of SKU Id's: ");
            try
            {
                AddUnitPrice(Convert.ToInt32(Console.ReadLine()));
                EnterScenarios();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }


        }

        #region Private functions to Process each options

        /// <summary>
        /// Select add/display options
        /// </summary>
        private void EnterScenarios()
        {
            int intNoUnits;
            List<string> lstProducts; 

            while (true)
            {
                Console.WriteLine("\n----------------------");
                Console.WriteLine("Choose one from below mentioed options");
                Console.WriteLine("1: Add Units");
                Console.WriteLine("2: Add Promotions");
                Console.WriteLine("3: Buy Products");
                Console.WriteLine("4: Display Units/Promotions");
                Console.WriteLine("5: Exit");
                Console.WriteLine("\n----------------------");
                switch(Console.ReadLine())
                {
                    case "1":
                        try
                        {
                            Console.Write("Enter number of SKU Id's: ");
                            AddUnitPrice(Convert.ToInt32(Console.ReadLine()));
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        break;
                    case "2":
                        try
                        {
                            Console.WriteLine("\n----------------------");
                            Console.Write("Enter number of Promotions to be applied: ");
                            AddPromotions(Convert.ToInt32(Console.ReadLine()));
                        }                       
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        break;

                    case "3":
                        lstProducts = new List<string>();
                        try
                        {
                            Console.WriteLine("\n----------------------");
                            Console.Write("\nEnter total number of products to buy :");
                            intNoUnits = Convert.ToInt32(Console.ReadLine());
                            for (int intIndex = 0; intIndex < intNoUnits; intIndex++)
                            {
                                Console.Write("\nEnter total number of units and unit name to buy without space:");
                                Console.WriteLine("\nEg. 1*A");
                                lstProducts.Add(Console.ReadLine());
                            }
                            objProcessEngine.CalculateUnitsAgainstPromotions(lstProducts);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        break;

                    case "4":
                        objProcessEngine.DisplayUnitsPromotions();
                        break;

                    case "5":Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Entered option is incorrect.Please choose correct one");
                        break;
                }
                

            }
            
        }

        /// <summary>
        /// Module to Add Promotions for the units
        /// </summary>
        /// <param name="activePromotions"></param>
        private void AddPromotions(int activePromotions)
        {
            string strPromotionUnits;
            int intPromotionValue;
            Dictionary<char,int> objResult=new Dictionary<char, int>();
            Console.WriteLine("\n\n----------------------");
            Console.Write("\nEnter total of {0} Promotions ", activePromotions);
            for (int index = 0; index < activePromotions; index++)
            {
                Console.Write("\nEnter {0} Promotion : ", index + 1);
                Console.Write("\n\nEnter number of units to apply promotion seperated by space ");
                Console.Write("\nEg. For  C & D for 30, enter units as C D.\n For 3 A's for 130, enter as A \n");
                strPromotionUnits = Console.ReadLine();
                var eachPromotionUnits = strPromotionUnits.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(x=>x.Trim());
                objResult = objProcessEngine.AddPromotionUnits(eachPromotionUnits);
                
                Console.Write("Enter Promotion value : ");
                intPromotionValue = Convert.ToInt32(Console.ReadLine());
                objProcessEngine.AddPromotion(objResult, intPromotionValue);
                
            }
        }

        /// <summary>
        /// Module to add Units and its respective fixed price
        /// </summary>
        /// <param name="NoOfUnits"></param>
        private void AddUnitPrice(int NoOfUnits)
        {
            char cUnitName;
            int intUnitValue;
            for(int index=0;index<NoOfUnits;index++)
            {
                Console.Write("\nEnter {0} SKU unit name (Eg. A of type char): ",index+1);
                cUnitName =Convert.ToChar(Console.ReadLine());
                Console.Write("Enter {0} unit value : ", cUnitName);
                intUnitValue =Convert.ToInt32(Console.ReadLine());
                objProcessEngine.UpdateUnitPrice(cUnitName, intUnitValue);
            }
        }
        #endregion

        /// <summary>
        /// Release the object from memory 
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            objProcessEngine.Dispose();
            base.Dispose(disposing);
        }

        #endregion
    }
}
