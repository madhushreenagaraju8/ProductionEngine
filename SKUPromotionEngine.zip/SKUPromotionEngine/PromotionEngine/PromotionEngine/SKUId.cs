﻿using System.Collections.Generic;

namespace PromotionEngine.Model
{
    public class SKUId
    {
        public Dictionary<char,int> DictSkuId { get; set; }
    }
}
