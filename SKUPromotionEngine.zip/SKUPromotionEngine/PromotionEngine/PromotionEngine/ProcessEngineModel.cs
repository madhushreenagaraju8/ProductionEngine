﻿using PromotionEngine.Model;
using System.Collections.Generic;

namespace PromotionEngine
{
    public class ProcessEngineModel
    {
        //To store unit and fixed value
        public SKUId ObjSkuid { get; set; }
        //Contains list of promotions
        public List<SKUPromotions> LstSkuPromotions { get; set; }
        //Products to buy in a given scenario
        public List<string> LstScenariosValues { get; set; }
    }
}
