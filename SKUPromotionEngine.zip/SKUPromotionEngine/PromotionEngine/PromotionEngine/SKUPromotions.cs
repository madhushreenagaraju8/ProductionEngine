﻿
namespace PromotionEngine.Model
{
    public class SKUPromotions:SKUId
    {
        public int IntPromotionValue { get; set; }

    }
}
